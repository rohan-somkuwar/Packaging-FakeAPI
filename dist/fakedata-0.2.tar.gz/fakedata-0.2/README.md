create a virtual environment

``
virtualenv venv
``

activate virtualenvironment

``
source venv/bin/activate
``

Installing the packages

``
pip install -r requirements.txt
``

